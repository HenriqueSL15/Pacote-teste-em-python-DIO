def log(msg):
    return print(msg)